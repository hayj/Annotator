sdDatabaseName = "serializabledict"
sdUser = None
sdPassword = None
sdHost = "localhost"
sdDatabaseRoot = None