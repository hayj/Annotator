mkdir -p ./data
cp /home/hayj/Data/Misc/crawling/shorteners.txt ./data/




